window.__web__ = {
    dev: true,
    version: '0.55',
    application_name: '������� ������',
    width: 1200,
    height: $(window).height() > 680 ? 680 : $(window).height(),
    style: 'blue', //    current stylesheet
    base_server_url: 'https://agent.prostoy.ru',
    upload_server_url: 'https://agent.prostoy.ru/appendfilepart.php',
    timeout: 5000,
    file_url: 'file.prostoy.ru',
    onload: {
        'xmlobject': {
            js: ['x2js']
        },
        'notice': {},
        'request': {},
        'tool': {
            js: ['custom.fn']
        },
        'lang': {
            js: ['moment']
        },
        'template': {
            js: ['mustache.min'],
            css: ['theme']
        },
        'interface': {
            ext: ['load'],
            css: ['interface', 'crcs', 'load']
        },
        'authorization': {
            ext: ['form', 'params'],
            css: ['auth'],
            js: ['cookie', 'md5'],
            req: true
        }
    },
    onstart: {
        'dataset': {
            cls: ['organization', 'project', 'user', 'group', 'task', 'category'],
            ext: ['tree'],
            js: ['storage'],
            req: true
        },
        'organization_block': {
            css: ['organization']
        },
        'user_block': {
            css: ['user_block']
        },
        'scene': {
            css: ['scene']
        },
        'router': {},
        'elements': {
            css: ['elements']
        },
        'windows': {
            js: ['draggable'],
            css: ['windows']
        },
        'tabs': {
            css: ['tabs']
        },
        'comments': {
            cls: ['comment'],
            css: ['simple_comment'],
            req: true
        },
        'list': {
            ext: ['comments', 'organizations', 'projects', 'tasks', 'users',
                'user_groups', 'categories', 'user_organization', 'contact_groups',
                'task_gateways'],
            req: true
        },
        'forms': {
            ext: ['comment.form', 'category.form', 'comment_move.form', 'comment_participants.form', 'comment_personal.form', 'send_mail_param.form'],
            css: ['comment', 'category', 'send_mail_param', 'comment_personal'],
            req: true
        },
        'table': {
            css: ['simple']
        },
        'tree': {},
        'viewer': {
            css: ['viewer']
        },
        'upload': {
            js: ['sparkMd5'],
            css: ['button']
        },
        'treeform': {
            cls: ['treeform.form', 'treeform.section', 'treeform.string', 'treeform.select', 'treeform.date', 'treeform.html'],
            css: ['tform'],
            ext: ['treeform.format', 'treeform.options', 'treeform.validate']
        }
    }
};