/**
 * ����� �������������
 * @type {Function}
 */
Scene.users = (function (template) {
    /** private */
    let local = {
        template: template,
        scene: null,
        groups_list: null,
        users_list: null,
        info_block: null,
        // project array
        group_array: [],
        user_array: [],
        selected_group_id: null,
        selected_user_id: null
    };
    /** public */
    return {
        /**
         * �������������
         * @returns {Scene.users}
         */
        init() {
            this.render();
            this.drawGroups();
            this.changeParams(Router.getParams());
            return this;
        },
        /**
         * ����������
         */
        render: function () {
            local.template.empty().append(Template.render('scene', 'users_scene'));
            local.scene = $('.users-scene', local.template);
            local.groups_list = $('.groups-list', local.template);
            local.users_list = $('.users-list', local.template);
            local.info_block = $('.info-block', local.template);
            this.addListener();
        },
        /**
         * ������ ������
         */
        drawGroups: function () {
            let org = OrganizationBlock.getCurrentOrganization();
            let groups = new List.UserGrops(org.getId());
            // ������ ������ ������ � ���, ��� �� ������� ������ �������
            local.scene.removeClass('user-lvl').removeClass('info-lvl');
            // sort
            groups.sortByName();
            let group_list = groups.list();
            for (let i = 0; i < group_list.length; i++) {
                let group = group_list[i];
                $(Template.render('scene', 'group_squire', {
                    name: group.getName(),
                    id: group.getId()
                })).appendTo(local.groups_list);
            }
        },
        /**
         * ������ �������������
         * @param group_id
         * @param callback
         */
        drawUsers: function (group_id, callback) {
            // ������� ������ ������ �����
            local.user_array = [];
            // ������� ����
            local.users_list.empty();
            // ������ ������ ������ � ���, ��� �� ������� ������ �������
            local.scene.removeClass('info-lvl');
            local.scene.addClass('user-lvl');

            let users = List.Users(group_id);
            users.sortByName();
            let users_list = users.list();
            for (let i = 0; i < users_list.length; i++) {
                let user = users_list[i];
                $(Template.render('scene', 'user_squire', {
                    name: user.getName(),
                    id: user.getId()
                })).appendTo(local.users_list);
            }
            if (typeof callback == 'function') {
                callback();
            }
        },
        /**
         * ������� �������
         */
        addListener: function () {
            local.groups_list.undelegate('.group-squire', 'click').delegate('.group-squire', 'click', function () {
                Router.changeParams([$(this).attr('id')]);
            });
            local.users_list.undelegate('.user-squire', 'click').delegate('.user-squire', 'click', function () {
                Router.changeParams([local.selected_group_id, $(this).attr('id')]);
            });
        },
        /**
         * ����� ������
         * @param id
         * @param callback
         */
        selectGroup: function (id, callback) {
            this.unSelectUser(local.selected_user_id);
            this.drawGroupTabs(local.selected_group_id);
            if (id != local.selected_group_id) {
                $('.group-squire.selected', local.groups_list).removeClass('selected').switchClass('to-right', 'to-bottom');
                local.selected_group_id = id;
                local.selected_user_id = null;
                local.groups_list.find('#' + id).eq(0).addClass('selected').switchClass('to-bottom', 'to-right');
                this.drawUsers(local.selected_group_id, callback);
            } else {
                if (typeof callback == 'function') {
                    callback();
                }
            }
        },
        /**
         * ����� �����
         * @param id
         * @param callback
         */
        selectUser: function (id, callback) {
            if (id != local.selected_user_id) {
                this.unSelectUser(local.selected_user_id);
                local.selected_user_id = id;
                local.users_list.find('#' + id).eq(0).addClass('selected').addClass('to-right');
                this.drawUserTabs(local.selected_user_id);
            } else {
                if (typeof callback == 'function') {
                    callback();
                }
            }
        },
        /**
         * ������ ������ � �����
         * @param user_id
         */
        unSelectUser: function (user_id) {
            $('.user-squire#' + user_id, local.users_list).removeClass('selected').removeClass('to-right');
            local.selected_user_id = null;
        },
        /**
         * ��������� ��������� �����
         * @param user_id
         */
        drawUserTabs: function (user_id) {
            local.info_block.empty().show();
            let lang = Lang.get();
            let tabs = new Tabs({
                tab_id: 'user_info_' + user_id,
                items: {
                    info: {
                        title: lang['scene']['tab']['info'],
                        content: function (block) {
                            let user = new User(local.selected_user_id);
                            block.append(TreeForm.getTreeForm('user', user.getDataToForm(), user.isEditable()).get());
                        }
                    },
                    chat: {
                        title: lang['scene']['tab']['chat'],
                        content: ''
                    },
                    job: {
                        title: lang['scene']['tab']['job'],
                        content: ''
                    }
                }
            });
            local.info_block.append(tabs.html());
        },
        /**
         * ��������� ��������� ������
         * @param group_id
         */
        drawGroupTabs: function (group_id) {
            local.info_block.empty().show();
            let lang = Lang.get();
            let tabs = new Tabs({
                tab_id: 'group_info_' + group_id,
                items: {
                    info: {
                        title: lang['scene']['tab']['info'],
                        content: ''
                    },
                    access: {
                        title: lang['scene']['tab']['access'],
                        content: ''
                    }
                }
            });
            local.info_block.append(tabs.html());
        },
        /**
         * ����������
         */
        reload: function () {
            let self = this;
            // �������
            local.selected_group_id = null;
            local.selected_user_id = null;
            // ������
            Router.changeParams([]);
            self.render();
            self.drawGroups();
        },
        /**
         * ������ ��������
         * @param callback
         */
        unbindScene: function (callback) {
            callback();
        },
        /**
         * ����� ����������
         * @param params
         */
        changeParams: function (params) {
            let self = this;
            if (typeof params != 'undefined') {
                switch (params.length) {
                    case 0:
                        self.reload();
                        break;
                    case 1:
                        self.selectGroup(params[0]);
                        break;
                    case 2:
                        self.selectGroup(params[0], function () {
                            self.selectUser(params[1]);
                        });
                        break;
                    case 3:
                        break;
                }
            }
        }
    };
});