/**
 * ����� ��������
 * @type {Function}
 */
Scene.contacts = (function (template) {
    /** private */
    let local = {
        template: template,
        scene: null,
        groups_list: null,
        contacts_list: null,
        info_block: null,
        // project array
        group_array: [],
        contact_array: [],
        selected_group_id: null,
        selected_contact_id: null
    };
    /** public */
    return {
        /**
         * �������������
         * @returns {Scene.contacts}
         */
        init: function () {
            this.render();
            this.drawGroups();
            this.changeParams(Router.getParams());
            return this;
        },
        /**
         * ����������
         */
        render: function () {
            local.template.empty().append(Template.render('scene', 'contacts_scene'));
            local.scene = $('.contacts-scene', local.template);
            local.groups_list = $('.groups-list', local.template);
            local.contacts_list = $('.contacts-list', local.template);
            local.info_block = $('.info-block', local.template);
            this.addListener();
        },
        /**
         * ���������� �����
         */
        drawGroups: function () {
            let org = OrganizationBlock.getCurrentOrganization();
            let groups = local.group_array = org.getContactsGroup();
            // ������ ������ ������ � ���, ��� �� ������� ������ �������
            local.scene.removeClass('contact-lvl').removeClass('info-lvl');
            // sort
            groups.sort(function (a, b) {
                let a_name = a.getName().toLowerCase();
                let b_name = b.getName().toLowerCase();
                if (a_name < b_name) {
                    return -1;
                }
                if (a_name > b_name) {
                    return 1;
                }
                return 0;
            });
            for (let i = 0; i < groups.length; i++) {
                let group = groups[i];
                $(Template.render('scene', 'contact_group_squire', {
                    name: group.getName(),
                    id: group.getId()
                })).appendTo(local.groups_list);
            }
        },
        /**
         * ���������� ���������
         * @param group_id
         * @param callback
         */
        drawContacts: function (group_id, callback) {
            // ������� ������ ������ �����
            local.contact_array = [];
            // ������� ����
            local.contacts_list.empty();
            // ������ ������ ������ � ���, ��� �� ������� ������ �������
            local.scene.removeClass('info-lvl');
            local.scene.addClass('contact-lvl');
            let group = new Project(group_id);
            group.getTasks(function (contacts) {
                local.contact_array = contacts;
                // sort
                contacts.sort(function (a, b) {
                    let a_name = (a.getName() || '').toLowerCase();
                    let b_name = (b.getName() || '').toLowerCase();
                    if (a_name < b_name) {
                        return -1;
                    }
                    if (a_name > b_name) {
                        return 1;
                    }
                    return 0;
                });
                for (let i = 0; i < contacts.length; i++) {
                    let contact = contacts[i];
                    $(Template.render('scene', 'contact_squire', {
                        name: contact.getName(),
                        id: contact.getId()
                    })).appendTo(local.contacts_list);
                }
                if (typeof callback == 'function') {
                    callback();
                }
            });
        },
        /**
         * ������� ��������
         */
        addListener: function () {
            local.groups_list.undelegate('.contact-group-squire', 'click').delegate('.contact-group-squire', 'click', function () {
                Router.changeParams([$(this).attr('id')]);
            });
            local.contacts_list.undelegate('.contact-squire', 'click').delegate('.contact-squire', 'click', function () {
                Router.changeParams([local.selected_group_id, $(this).attr('id')]);
            });
        },
        /**
         * ����� ������
         * @param id
         * @param callback
         */
        selectGroup: function (id, callback) {
            this.unSelectContact(local.selected_contact_id);
            this.drawGroupTabs(id);
            if (id != local.selected_group_id) {
                $('.contact-group-squire.selected', local.groups_list).removeClass('selected').switchClass('to-right', 'to-bottom');
                local.selected_group_id = id;
                local.selected_contact_id = null;
                local.groups_list.find('#' + id).eq(0).addClass('selected').switchClass('to-bottom', 'to-right');
                this.drawContacts(local.selected_group_id, callback);
            } else {
                if (typeof callback == 'function') {
                    callback();
                }
            }
        },
        /**
         * ����� ��������
         * @param id
         * @param callback
         */
        selectContact: function (id, callback) {
            if (id != local.selected_contact_id) {
                this.unSelectContact(local.selected_contact_id);
                local.selected_contact_id = id;
                local.contacts_list.find('#' + id).eq(0).addClass('selected').addClass('to-right');
                this.drawContactTabs(local.selected_contact_id);
            }
        },
        /**
         * ����� ����� � ��������
         * @param contact_id
         */
        unSelectContact: function (contact_id) {
            $('.contact-squire#' + contact_id, local.contacts_list).removeClass('selected').removeClass('to-right');
            local.selected_contact_id = null;
        },
        /**
         * ��������� ���������� ��� ��������
         * @param contact_id
         */
        drawContactTabs: function (contact_id) {
            local.info_block.empty().show();
            let lang = Lang.get();
            let tabs = new Tabs({
                tab_id: 'contact_info_' + contact_id,
                items: {
                    info: {
                        title: lang['scene']['tab']['info'],
                        content: ''
                    }
                }
            });
            local.info_block.append(tabs.html());
        },
        /**
         * ��������� ���������� ��� ������
         * @param group_id
         */
        drawGroupTabs: function (group_id) {
            local.info_block.empty().show();
            let lang = Lang.get();
            let tabs = new Tabs({
                tab_id: 'group_info_' + group_id,
                items: {
                    info: {
                        title: lang['scene']['tab']['info'],
                        content: ''
                    },
                    access: {
                        title: lang['scene']['tab']['access'],
                        content: ''
                    }
                }
            });
            local.info_block.append(tabs.html());
        },
        /**
         * ������������
         */
        reload: function () {
            // �������
            local.selected_group_id = null;
            local.selected_contact_id = null;
            // ������
            Router.changeParams([]);
            this.render();
            this.drawGroups();
        },
        /**
         * ����� ����� �� �����
         * @param callback
         */
        unbindScene: function (callback) {
            callback();
        },
        /**
         * ����� ����������
         * @param params
         */
        changeParams: function (params) {
            let self = this;
            if (typeof params != 'undefined') {
                switch (params.length) {
                    case 0:
                        self.reload();
                        break;
                    case 1:
                        self.selectGroup(params[0]);
                        break;
                    case 2:
                        self.selectGroup(params[0], function () {
                            self.selectContact(params[1]);
                        });
                        break;
                    case 3:
                        break;
                }
            }
        }
    };
});