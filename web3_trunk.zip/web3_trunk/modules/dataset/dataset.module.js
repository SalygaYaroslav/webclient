/**
 *
 * @type {{storage, init, save, checkNews, parseNews, flushStorage, checkNotification, getCustomStorage, setCustomStorage, getEntity, getEntityFromServer, Tree}}
 */
var Dataset = (function () {
    /** private */
    let storage = {
        key: Authorization.getUserAuthData('login'),
        time_delay: 0,
        time_title: '',
        timeout: null,
        data: {
            version: __web__.version,
            entities: {
                organizations: {},
                categorys: {},
                groups: {},
                projects: {},
                tasks: {},
                users: {}
            },
            logins: {},
            update: {
                last_id: '0',
                last_oper: '0',
                date: null,
                inprocess: false
            },
            storage_version: null,
            tree: {
                "other": {
                    c: {},
                    p: {},
                    g: {},
                    u: {}
                }
            }
        }
    };
    /** public */
    return {
        /** storage */
        storage: storage,
        /**
         * �������������
         * @param callback ������
         * @returns {*}
         */
        init: function (callback) {
            let data = $.jStorage.get('webclient.storage:' + storage.key);
            /** check data and version */
            if (data && data.version == __web__.version) {
                storage.data = data;
            }
            return callback(storage.data.update.last_id);
        },
        /**
         * save
         */
        save: function () {
            return $.jStorage.set('webclient.storage:' + storage.key, storage.data);
        },
        /**
         * �������� �������
         * @param callback ������
         * @returns {boolean}
         */
        checkNews: function (callback) {
            let self = this;
            // check is news getting now
            if (storage.inprocess == true) {
                return false;
            }
            storage.inprocess = true;
            // get news
            self.getNews(callback);
        },
        /**
         * ������� �������
         * @param callback
         */
        getNews: function (callback) {
            let self = this;
            Request.getNews(
                storage.data.update.last_id,
                function (data) { // success
                    let news_object = data.object();
                    if (news_object['_status'] == 'OK') {
                        storage.inprocess = false;
                        if (storage.timeout) {
                            window.clearTimeout(storage.timeout);
                        }
                        storage.timeout = window.setTimeout(function () {
                            self.checkNews();
                        }, 60000);
                        self.parseNews(data);
                        if (typeof callback == 'function') {
                            callback();
                        }
                    } else {
                        // error(data);
                    }
                }
            );
        },
        /**
         * ������ ������ �� ��������
         * @param news
         */
        parseNews: function (news) {
            let xml = news.xml();
            let update = storage.data.update;
            let entities = storage.data.entities;
            // delay
            storage.time_delay = moment($('news', xml).attr('server_time')).diff(moment(), 'hours');
            storage.time_title = moment().format("DD.MM.YYYY HH:mm:ss");
            // go go go
            let sound = false;
            for (let id in entities) {
                if (entities.hasOwnProperty(id)) {
                    let entity_type = id.substring(0, id.length - 1);
                    $(entity_type + 's > ' + entity_type, xml).each(function (i, entity) {
                        let entity_object = new window[entity_type.capitalize()]().set(entity);
                        switch (entity_type) {
                            case 'task':
                                if (Router.getPage() == 'projects') {
                                    let params = Router.getParams();
                                    let id = entity_object.getId();
                                    if (params.length > 1 && params[1] == id) {
                                        $(document).trigger('webclient.comments.update.' + id);
                                    }
                                }
                                sound = true;
                                break;
                        }
                    });
                }
            }
            $('comvotes > comvote', xml).each(function (i, vote) {
                let task_id = $('task_id', vote).text();
                // ���� ������ ������� ����� ��������� ���� ������, ��
                // ��������� �����
                if (Router.getPage() == 'projects') {
                    let params = Router.getParams();
                    if (params.length > 1 && params[1] == task_id) {
                        $(document).trigger('webclient.comments.vote', vote);
                    }
                }
            });
            if ($('losts', xml).length > 0) {
                for (let id in entities) {
                    if (entities.hasOwnProperty(id)) {
                        let entity_type = id.substring(0, id.length - 1);
                        if ($('losts > ' + entity_type + 's', xml).length > 0) {
                            let ids = $('losts > ' + entity_type + 's', xml).text().split(',');
                            for (let i = 0; i < ids.length; i++) {
                                let object_entity = new window[entity_type.capitalize()](ids[i]);
                                object_entity.remove();
                            }
                        }
                    }
                }
            }
            if ($('news', xml).attr('last') != 'nope') {
                update.last_oper = update.last_id;
                update.last_id = $('news', xml).attr('last');
            }
            // ������
            Dataset.Tree.buildTree(xml);
            this.save();
            // if (sound) {
            //     Tool.playAudio('/sounds/inbox.news.mp3');
            // }
        },
        /**
         * ������� ���������
         */
        flushStorage: function () {
            $.jStorage.flush();
            window.location.reload();
        },
        // /**
        //  * �������� �����������
        //  * @param tasks ������
        //  * @param comments ��������
        //  * @param crmobjects ����������
        //  * @returns {boolean}
        //  */
        // checkNotification: function (tasks, comments, crmobjects) {
        //     let task_ids = [];
        //     for (let i = 0; i < tasks.length; i++) {
        //         task_ids.push(tasks[i].id + ':' + storage.data.update.last_oper);
        //     }
        //     // task_ids = task_ids.join(',');
        //     return true;
        // }
        /**
         * �������� ��������� ���������
         * @param storage_name �������� ������
         */
        getCustomStorage: function (storage_name) {
            return $.jStorage.get('webclient.' + storage_name + ':' + storage.key);
        },
        /**
         * ������ ��������� ���������
         * @param storage_name �������� ������
         * @param storage_object ������ ������
         */
        setCustomStorage: function (storage_name, storage_object) {
            $.jStorage.set('webclient.' + storage_name + ':' + storage.key, storage_object);
        },
        /**
         * ������� �������� �� ���������
         * ���� ��� � ��������� - ������� � �������
         * ���� ��� �� ������� - ������ null
         * @param type_ ��� ��������
         * @param id_ id ��������
         * @returns {*}
         */
        getEntity: function (type_, id_) {
            let self = this;
            if (typeof type_ != 'undefined' && typeof id_ != 'undefined') {
                if (typeof storage.data.entities[type_ + 's'] != 'undefined' && typeof storage.data.entities[type_ + 's'][id_] != 'undefined') {
                    return storage.data.entities[type_ + 's'][id_];
                } else {
                    return self.getEntityFromServer(type_, id_, function (type_, id_, data_) {
                        if (!data_) {
                            return null;
                        }
                        let xml = data_.xml();
                        if (typeof xml == 'undefined' || $('denied', xml).text() == true) {
                            return null;
                        }
                        $(type_, xml).each(function (i, item) {
                            new window[type_.capitalize()]().set(item);
                        });
                        // ��������
                        self.save();
                        // ������ ������
                        if (typeof storage.data.entities[type_ + 's'] != 'undefined' && typeof storage.data.entities[type_ + 's'][id_] != 'undefined') {
                            return storage.data.entities[type_ + 's'][id_];
                        } else {
                            return null;
                        }
                    });
                }
            } else {
                return null;
            }
        },
        /**
         * ������� �������� � �������
         * @param {string} type ��� ��������
         * @param {int} id id ��������
         * @param {function} callback �������
         * @returns {*}
         */
        getEntityFromServer: function (type, id, callback) {
            switch (type) {
                case 'job':
                    break;
                default:
                    return callback(type, id, Request.getEntity(type, id));
                    break;
            }
        },
        loadTasks: function (callback) {
            let array = [];
            let organizations = Authorization.getCurrentUser().getUserOrganization();
            for (let i = 0; i < organizations.length; i++) {
                let projects = organizations[i].getProjects();
                array = array.concat(projects);
                let groups = organizations[i].getContactsGroup();
                array = array.concat(groups);
            }
            array = array.concat(new Organization('other').getProjects());
            this.lazyLoad(array, callback);
        },
        lazyLoad: function (array, callback) {
            let self = this;
            let lang = Lang.get()['dataset'];
            if (array.length > 0) {
                let name = array[0].getName();
                let type = array[0].isContactGroup();
                Interface.Load.show(lang['loading'] + ((type) ? ' ' + lang['contacts'] + ' ' : ' ' + lang['tasks'] + ' ' ) + name);
                array[0].getTasks(function () {
                    array.cleanByIndex(0);
                    self.lazyLoad(array, callback);
                })
            } else {
                callback();
            }
        },
        getSizes: function () {
            let xLen, log = [], total = 0;
            for (let x in localStorage) {
                if (localStorage.hasOwnProperty(x)) {
                    xLen = ((localStorage[x].length * 2 + x.length * 2) / 1024);
                    total += xLen
                }
            }
            log.unshift("�������<br>������ ��<br> " + Tool.formatBytes(total));
            return log.join("\n");
        }
    };
})();