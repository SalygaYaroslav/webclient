/**
 *
 * @param id
 * @returns {{classname: string, getEntityField: getEntityField, set: set, remove: remove, getId: getId, getName: getName, getAvatar: getAvatar, getProjects: getProjects, getContactsGroup: getContactsGroup, getUserGroups: getUserGroups, isUserInTeam: isUserInTeam, getUsers: getUsers, getStatus: getStatus, getStatusAvatarClass: getStatusAvatarClass, isAdmin: isAdmin, checkProjectsDifference: checkProjectsDifference, getCategories: getCategories, getRouters: getRouters, userInFired: userInFired}}
 * @constructor
 */
var Organization = function (id) {
    /** private **/
    let classname = 'Organization';
    let local = {
        entity: {},
        group_access: {},
        admin_group_access: {},
        admins: {}
    };
    /** constructor **/
    if (typeof id != 'undefined') {
        if (id == 'other') {
            local.entity = {
                id: 'other',
                title: Lang.get()['dataset']['org']['private']
            };
        } else {
            local = Dataset.getEntity('organization', id);
        }
    }
    /** public **/
    return {
        classname: classname,
        /**
         * ������� ����
         * @param field
         * @returns {*|string}
         */
        getEntityField: function (field) {
            if (typeof field == 'undefined') {
                return local.entity;
            }
            return local.entity[field] || '';
        },
        /**
         * ������ ������
         * @param organization
         * @returns {Organization}
         */
        set: function (organization) {
            let entities = Dataset.storage.data.entities['organizations'];
            let id = $('id', organization).text();
            if (typeof entities[id] == 'undefined') {
                local.entity = Tool.xmlToJson(organization);
            } else {
                local = entities[id];
                local.entity = $.extend({}, entities[id].entity, Tool.xmlToJson(organization));
                /** �������� �� ��������� � �������� ��������**/
                // this.checkProjectsDifference();
            }
            if ($('groups', organization).length > 0) {
                Dataset.Tree.clearOrganizationGroups(id);
            }
            $('groups > group', organization).each(function (i, group) {
                new Group().set(group);
            });
            /** admins **/
            $('admins > user', organization).each(function (i, admin) {
                let id = $(admin).attr('id');
                local.admins[id] = {};
                local.admins[id]['creator'] = ($(admin).attr('creator') || 'false').toBoolean();
                local.admins[id]['spec_access'] = $(admin).attr('spec_access') || null;
                if ($('user_data', admin).length > 0) {
                    local.admins[id]['user_data'] = Tool.xmlToJson(admin)['user_data'];
                }
            });
            $('clients_groups > group', organization).each(function (i, group) {
                let group_object = Tool.xmlAttrToJson(group);
                local.group_access[group_object.id] = group_object;
            });
            $('admins_groups > group', organization).each(function (i, group) {
                let group_object = Tool.xmlAttrToJson(group);
                local.admin_group_access[group_object.id] = group_object;
            });
            entities[id] = local;
            return this;
        },
        /**
         * ������ �� ���������
         */
        remove: function () {
            let entities = Dataset.storage.data.entities['organizations'];
            if (typeof entities[local.entity.id] != 'undefined') {
                delete entities[local.entity.id];
            }
        },
        /**
         * ������� ��
         * @returns {string|string}
         */
        getId: function () {
            if (!local) {
                return '';
            }
            return local.entity.id || '';
        },
        /**
         * ������� ���
         * @returns {string|string}
         */
        getName: function () {
            return local.entity.title || Lang.get()['dataset']['org']['no_name'];
        },
        /**
         * ������� ������
         * @returns {*}
         */
        getAvatar: function () {
            if (typeof local.entity.avatarName != 'undefined') {
                return 'https://' + __web__.file_url + '/' + local.entity.avatarName;
            } else {
                return false;
            }
        },
        /**
         * ������� �������
         * @returns {Array}
         */
        getProjects: function () {
            let projects = [];
            let project_ids = Dataset.Tree.getProjectIds(this.getId());
            for (let i = 0; i < project_ids.length; i++) {
                let project = new Project(project_ids[i]);
                if (project.isProject()) {
                    projects.push(project);
                }
            }
            return projects;
        },
        /**
         * ������� ������ ���������
         * @returns {Array}
         */
        getContactsGroup: function () {
            let groups = [];
            let group_ids = Dataset.Tree.getProjectIds(this.getId());
            for (let i = 0; i < group_ids.length; i++) {
                let group = new Project(group_ids[i]);
                if (group.isContactGroup()) {
                    groups.push(group);
                }
            }
            return groups;
        },
        /**
         * ������� ������ �������������
         * @param with_default
         * @param no_fired
         * @returns {Array}
         */
        getUserGroups: function (with_default, no_fired) {
            let group_ids = Dataset.Tree.getGroupIds(this.getId());
            let result = [];
            for (let i = 0; i < group_ids.length; i++) {
                let group = new Group(group_ids[i]);
                result.push(group);
                if (no_fired && this.groupIsFired(group)) {
                    continue;
                }
            }
            if (typeof with_default != 'undefined') {
                result.push(new Group('default_' + this.getId()));
            }
            return result;
        },
        /**
         * �������� ����� � �����������
         * @param user_id
         * @returns {boolean}
         */
        isUserInTeam: function (user_id) {
            let users_array = Dataset.Tree.getUserIds(this.getId());
            return ($.inArray(user_id, users_array) != '-1');
        },
        /**
         * ������� ������ ������ �����������
         * @returns {Array}
         */
        getUsers: function () {
            let users_array = [];
            let ids_array = Dataset.Tree.getUserIds(this.getId());
            for (let i = 0; i < ids_array.length; i++) {
                users_array.push(new User((ids_array[i])));
            }
            return users_array;
        },
        /**
         * ������� ������
         * @returns {*|string|number}
         */
        getStatus: function () {
            return local.entity.status;
        },
        /**
         * ������� ������ ������
         * @returns {string}
         */
        getStatusAvatarClass: function () {
            let status = 'standart';
            switch (this.getStatus()) {
                case 'prof':
                    status = 'prof';
                    break;
                case 'standart':
                    if (this.isAdmin()) {
                        status = 'admin';
                    }
                    break;
            }
            return status;
        },
        /**
         * �������� �� ������
         * @param id
         * @returns {boolean}
         */
        isAdmin: function (id) {
            let uid = id || Authorization.getCurrentUser().getId();
            for (let id in local.admin_group_access) {
                let group = new Group(id);
                if ($.inArray(uid, group.getUsers()) != "-1") {
                    return true;
                }
            }
            return (typeof local.admins[uid] != 'undefined' || local.entity.ownerId == uid);
        },
        /**
         *
         * @param id
         * @returns {string}
         */
        getUserSign: function (id) {
            let sign = '';
            if (typeof id == 'undefined') {
                id = Authorization.getCurrentUser().getId();
            }
            if (typeof local.admins[id] != 'undefined') {
                if (typeof local.admins[id]['user_data'] != 'undefined' && typeof local.admins[id]['user_data']['u_mail_postfix'] != 'undefined') {
                    sign = local.admins[id]['user_data']['u_mail_postfix'];
                }
            }
            return sign;
        },
        /**
         * �������� �������� ������ ��������
         * @returns {{}}
         */
        checkProjectsDifference: function () {
            let projects = Request.loadOrgProjects(this.getId());
            let projects_array = projects.xml();
            let new_ids = [];
            let temp_projects = {};
            $('project', projects_array).each(function (i, item) {
                let project = Tool.xmlToJson(item);
                new_ids.push(project.id);
                temp_projects[project.id] = project;

            });
            let old_ids = Dataset.Tree.getProjectIds(this.getId());
            let diff = {
                to_add: [],
                to_remove: []
            };
            diff.to_remove = old_ids.difference(new_ids);
            if (to_remove.length > 0) {
                for (let i = 0; i < to_remove.length; i++) {
                    new Project(to_remove[i]).remove();
                }
            }
            diff.to_add = new_ids.difference(old_ids);
            if (diff.to_add.length > 0) {
                for (let i = 0; i < diff.to_add.length; i++) {
                    new Project().set(temp_projects[diff.to_add[i]]);
                }
            }
            return diff;
        },
        /**
         * ������� ���������
         * @returns {Array}
         */
        getCategories: function () {
            let category_ids = Dataset.Tree.getCategoryIds(this.getId());
            let categories = [];
            for (let i = 0; i < category_ids.length; i++) {
                categories.push(new Category(category_ids[i]));
            }
            return categories;
        },
        getRouters: function () {
            let response = Request.getRouters(this.getId());
            let xml = response.xml();
            let gateways = [];
            $('mailgateway', xml).each(function () {
                gateways.push(Tool.xmlToJson(this));
            });
            return gateways;
        },
        groupIsFired: function (group) {
            if (local.entity['dismissed_group_id'] && local.entity['dismissed_group_id'] != '' && local.entity['dismissed_group_id'] != '0') {
                return local.entity['dismissed_group_id'] == group.getId();
            }
        },
        userInFired: function (user) {
            //������� ������� ���� �� ���� ������ ���������
            if (local.entity['dismissed_group_id'] && local.entity['dismissed_group_id'] != '' && local.entity['dismissed_group_id'] != '0') {
                return new Group(local.entity['dismissed_group_id']).userInGroup(user);
            }
            return false;
        }
    };
};