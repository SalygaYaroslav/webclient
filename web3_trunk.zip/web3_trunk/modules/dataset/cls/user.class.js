/**
 *
 * @param id
 * @returns {{classname: string, getEntityField: getEntityField, set: set, remove: remove, getId: getId, getName: getName, getAvatar: getAvatar, getUserOrganization: getUserOrganization, getUserGenderClass: getUserGenderClass}}
 * @constructor
 */
var User = function (id) {
    let classname = 'User';
    let local = {
        entity: {}
    };
    // get from storages
    if (typeof id != 'undefined') {
        if (id == 'system') {
            local.entity = {};
        } else {
            local = Dataset.getEntity('user', id);
        }
    }
    // functions
    return {
        classname: classname,
        /**
         * ������� ����
         * @param field
         * @returns {*|string}
         */
        getEntityField: function (field) {
            if (typeof field == 'undefined') {
                return local.entity;
            }
            return local.entity[field] || '';
        },
        getDataToForm: function () {
            this.needFull();
            console.log(local.entity)
            return local.entity;
        },
        /**
         * ������ ������
         * @param user
         * @returns {User}
         */
        set: function (user) {
            let entities = Dataset.storage.data.entities['users'];
            let id = $('id', user).text();
            let login = Tool.decode($('login', user).text());
            Dataset.storage.data.logins[login] = id;
            if (typeof entities[id] == 'undefined') {
                local.entity = Tool.xmlToJson(user);
            } else {
                local = entities[id];
                local.entity = $.extend({}, entities[id].entity, Tool.xmlToJson(user));
            }
            entities[id] = local;
            return this;
        },
        /**
         * ������ �� ���������
         */
        remove: function () {
            let entities = Dataset.storage.data.entities['users'];
            let logins = Dataset.storage.data.logins;
            if (typeof logins[local.entity.login] != 'undefined') {
                delete logins[local.entity.login];
            }
            if (typeof entities[local.entity.id] != 'undefined') {
                delete entities[local.entity.id];
            }
        },
        needFull: function () {
            let self = this;
            let result = Dataset.Tree.getFullUser(self);
            switch (result) {
                case true:
                    break;
                case false:
                    break;
                default:
                    self = result;
                    break;
            }
        },
        /**
         * ������� ��
         * @returns {string|string}
         */
        getId: function () {
            return local.entity.id || '';
        },
        /**
         * ������� �����
         * @returns {string|string}
         */
        getLogin: function () {
            return local.entity.login || '';
        },
        /**
         * ������� ���
         * @returns {*}
         */
        getName: function () {
            try {
                if (typeof local.entity.vcRealName != 'undefined' && typeof local.entity.vcSurname != 'undefined') {
                    return local.entity.vcRealName + ' ' + local.entity.vcSurname;
                } else if (typeof local.entity.vcName != 'undefined') {
                    return local.entity.vcName;
                } else {
                    return local.entity.login;
                }
            } catch (e) {
                return '';
            }
        },
        /**
         * ������� ������
         * @returns {*}
         */
        getAvatar: function () {
            if (typeof local.entity.avatarName != 'undefined' && local.entity.avatarName) {
                return 'http://' + __web__.file_url + '/' + local.entity.avatarName;
            } else {
                let avatar = 'unknown';
                switch (this.getUserGenderClass()) {
                    case '1':
                        avatar = 'male';
                        break;
                    case '0':
                        avatar = 'female';
                        break;
                }
                return 'http://' + location.hostname + '/images/icons/userblock_' + avatar + '.svg';
            }
        },
        /**
         * ������� ������ ����������� �����
         * @returns {Array}
         */
        getUserOrganization: function () {
            let org_ids = Dataset.Tree.getOrganizationIds();
            let org_array = [];
            for (let i = 0; i < org_ids.length; i++) {
                let org = new Organization(org_ids[i]);
                if (org.isUserInTeam(this.getId())) {
                    org_array.push(org);
                }
            }
            return org_array;
        },
        /**
         * ������� ����� �������
         * @returns {string}
         */
        getUserGenderClass: function () {
            let gender = local.entity.gender;
            let avatar = 'unknown';
            switch (gender) {
                case '1':
                    avatar = 'male';
                    break;
                case '0':
                    avatar = 'female';
                    break;
            }
            return avatar;
        },
        isEditable: function () {
            return local.entity.id == Authorization.getCurrentUser().getId();
        }
    };
};