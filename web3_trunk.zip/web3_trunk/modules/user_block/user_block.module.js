/**
 * ���� �����
 * @type {{init, render}}
 */
var UserBlock = (function () {
    /** private */
    let local = {
        main_block: null
    };
    /** public */
    return {
        /**
         * ������������� ����� �����������
         * @param block
         * @returns {boolean}
         */
        init: function (block) {
            local.main_block = block;
            this.render();
            return this;
        },
        /**
         * �������� �������
         * @returns {*}
         */
        render: function () {
            let user = Authorization.getCurrentUser();
            let template = $(Template.render('user_block', 'form', {
                name: user.getName(),
                id: user.getId(),
                avatar: user.getUserGenderClass()
            }));
            local.main_block.append(template);
            this.bind();
        },
        /**
         * �������
         */
        bind: function () {
            local.main_block.on('click', function () {
                if (local.main_block.hasClass('show-params')) {
                    local.main_block.removeClass('show-params');
                } else {
                    local.main_block.addClass('show-params');
                    // close on body click
                    $('body').off('click.user_params').on('click.user_params', function (e) {
                        if (!$(e.target).hasClass('w-carcase-personal') && $(e.target).parents('.w-carcase-personal').length == 0) {
                            local.main_block.removeClass('show-params');
                            $('body').off('click.user_params');
                        }
                    });
                }
            });

            $('.--exit', local.main_block).on('click', function () {
                Authorization.logout();
            });
            $('.--storage', local.main_block).on('click', function () {
                Dataset.flushStorage();
            });
            $('.--params', local.main_block).on('click', function () {
                let params = new Authorization.Params();
                params.show();
            });
        }
    };
})();