$(function () {
    $('body').delegate('[draggable]', 'dragstart', function (e) {
        let event = e.originalEvent;
        let style = window.getComputedStyle(e.target, null);
        let left = parseInt(style.getPropertyValue("left"), 10) - e.clientX;
        let top = parseInt(style.getPropertyValue("top"), 10) - e.clientY;
        let id = 'drag_' + new Date().getTime();
        let data = [left, top, id];
        $(e.target).attr('data-drag', id);
        event.dataTransfer.setData("text/plain", data.join(','));
    });
    document.body.addEventListener('dragover', function (event) {
        event.preventDefault();
        return false;
    }, false);
    document.body.addEventListener('drop', function (event) {
        let data = event.dataTransfer.getData("text/plain").split(',');
        if (data.length > 1) {
            let id = data[2];
            let element = $('[data-drag=' + id + ']').eq(0);
            let old = {
                left: data[0],
                top: data[1]
            };
            let max = {
                left: $(window).width(),
                top: $(window).height()
            };
            let left = (event.clientX + parseInt(old.left, 10));
            let top = (event.clientY + parseInt(old.top, 10));
            if ((left + element.width()) > max.left) {
                left = max.left - element.width() - 10;
            }
            if (left < 0) {
                left = 10;
            }
            if ((top + element.height()) > max.top) {
                top = max.top - element.height() - 10;
            }
            if (top < 0) {
                top = 10;
            }
            element.css({
                left: left + 'px',
                top: top + 'px'
            });
            $.removeAttr(element, 'data-drag');
            event.preventDefault();
            return false;
        }
    }, false);
});
