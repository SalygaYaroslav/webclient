/**
 * ������ �����������
 * @param type
 * @returns {{list: list, sort: sort, removePrivate: removePrivate, convertToSelect: convertToSelect}}
 * @constructor
 */
List.Organizations = function (type) {
    /** private */
    let local = {
        list: [],
        order: null
    };
    /** constructor */
    switch (type) {
        case 'all':
            let ids = Dataset.Tree.getOrganizationIds();
            for (let i = 0; i < ids.length; i++) {
                local.list.push(new Organization(ids[i]));
            }
            break;
        case 'user':
            if (arguments.length == 2) {
                let user_id = arguments[1];
                local.list = new User(user_id).getUserOrganization();
            } else {
                local.list = Authorization.getCurrentUser().getUserOrganization();
            }
            break;
        default:
            break;
    }
    /** public */
    return {
        /**
         * ������ �����������
         * @returns {Array}
         */
        list: function () {
            return local.list;
        },
        /**
         * ����������
         * @param order
         */
        sort: function (order) {
            local.list.sort(function (first, second) {
                let first_value = first.getEntityField(order);
                let second_value = second.getEntityField(order);
                if (first_value < second_value) {
                    return -1;
                } else if (first_value > second_value) {
                    return 1;
                } else {
                    return 0;
                }
            })
        },
        /**
         * ������� ��������� ���. �� ������
         */
        removePrivate: function () {
            for (let i = 0; i < local.list.length; i++) {
                if (local.list[i].getId() == 'other') {
                    local.list.cleanByIndex(i);
                }
            }
        },
        /**
         * ������������ � ������
         * @param default_value
         * @returns {*|jQuery}
         */
        convertToSelect: function (default_value) {
            let div = $('<div>').addClass('lst-select --organization');
            let select = $('<select>').appendTo(div);
            for (let i = 0; i < local.list.length; i++) {
                let org = local.list[i];
                $('<option>').val(org.getId()).html(org.getName()).attr('title', org.getName()).appendTo(select);
            }
            if (typeof default_value != 'undefined') {
                select.val(default_value);
            }
            return div;
        }
    };
};