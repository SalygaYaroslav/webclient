/**
 * ������
 * @type {{Comments, Organizations, Projects, Tasks, Categories, Users, UserGroups, ContactGroups, TaskGateways}}
 */
var List = (function () {
    /** private */
    let data = {};
    /** public */
    return {};
})();