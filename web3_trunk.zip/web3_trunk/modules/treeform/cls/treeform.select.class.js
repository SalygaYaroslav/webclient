TreeForm.Select = function (config, data) {
    let local = {
        id: config.id,
        title: config.title,
        multi: config.multi,
        split: config.split || ',',
        data: data || '',
        placeholder: config.placeholder,
        visible: config.visible,
        format: config.format || null,
        options: config.options || null,
        element: null,
        input: null
    };
    let fns = {
        element: 'select',
        render: function () {
            let array_of_elements = function () {
                let value = data[config.id];
                let array = ((value) ? value.split(config.split) : []);
                if (array.length == 0) {
                    array = [''];
                }
                return array;
            }();
            local.element = $(Template.render('treeform', 'elements/select', {
                id: local.id,
                title: local.title,
                placeholder: local.placeholder,
                multi: local.multi.toString().toBoolean(),
                options: function () {
                    try {
                        return TreeForm.Options[local.options];
                    } catch (e) {
                        return [];
                    }
                }(),
                elements: array_of_elements
            }));
            for (let i = 0; i < array_of_elements.length; i++) {
                local.element.find('select').eq(i).val(array_of_elements[i]);
            }
            return local.element.data({'object': this});
        },
        title: function () {
            return local.title;
        }
    };
    return fns;
};