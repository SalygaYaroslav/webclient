TreeForm.Date = function (config, data) {
    let local = {
        id: config.id,
        title: config.title,
        multi: config.multi,
        split: config.split || ',',
        data: data || '',
        placeholder: config.placeholder,
        visible: config.visible,
        format: config.format || null,
        element: null,
        input: null
    };
    let fns = {
        element: 'date',
        render: function () {
            local.element = $(Template.render('treeform', 'elements/string', {
                id: local.id,
                title: local.title,
                placeholder: local.placeholder,
                multi: local.multi.toString().toBoolean(),
                elements: function () {
                    let value = data[config.id];
                    let array = ((value) ? value.split(config.split) : []);
                    if (array.length == 0) {
                        array = [''];
                    }
                    return array;
                }()
            }));
            return local.element.data({'object': this});
        },
        title: function () {
            return local.title;
        }
    };
    return fns;
};