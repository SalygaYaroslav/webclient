/**
 *
 * @param config
 * @param data
 * @param access
 * @returns {{}}
 * @constructor
 */
TreeForm.Form = function (config, data, access) {
    /** private */
    let local = {
        config: config || [],
        data: data || {},
        work: {
            access: access || false,
            temp: {},
            template: null
        }
    };
    /**
     * public
     * @type {{}}
     */
    let fns = {
        initialization: function () {
            if (local.config.length > 0) {
                for (let i = 0; i < local.config.length; i++) {
                    let object = local.config[i];
                    let id = Object.keys(object)[0];
                    let values = object[id];
                    local.work.temp[id] = function (config) {
                        let element = null;
                        switch (config.type) {
                            case 'section':
                                let section = new TreeForm.Section({
                                    id: id,
                                    title: config.title,
                                    children: config.children,
                                    access: local.work.access
                                }, local.data);
                                element = section.render();
                                break;
                        }
                        return element;
                    }(values);
                }
            }
            fns.render();
        },
        render: function () {
            local.work.template = $(Template.render('treeform', 'form'));
            let container = $('.tform-sections', local.work.template);
            for (let id in local.work.temp) {
                container.append(local.work.temp[id]);
            }
            local.work.template.data('object', this);
        },
        get: function () {
            return local.work.template;
        }
    };
    fns.initialization();
    return fns;
};