TreeForm.Section = function (config, data) {
    /** private */
    let local = {
        config: $.extend({
            id: '',
            title: '',
            expand: true,
            access: false,
            children: []
        }, config),
        data: data || {},
        work: {
            elements: [],
            titles: [],
            expand: false,
            template: null
        }
    };
    let fns = {
        element: 'section',
        render: function () {
            local.work.elements = [];
            for (let i = 0; i < local.config.children.length; i++) {
                let object = local.config.children[i];
                let id = Object.keys(object)[0];
                let values = object[id];
                let type = values.type;
                if (local.data[id]) {
                    local.work.expand = true;
                }
                try {
                    switch (type) {
                        case 'section':
                            local.work.expand = true;
                            let element = new TreeForm[type.capitalize()]($.extend(values, {
                                id: id,
                                access: local.config.access
                            }), (local.data || null));
                            local.work.elements.push(element.render());
                            break;
                        default:
                            if (local.config.access) {
                                let element = new TreeForm[type.capitalize()]($.extend(values, {id: id}), (local.data || null));
                                local.work.elements.push(element.render());
                                local.work.titles.push(element.title());
                            } else {
                                local.work.elements.push(new TreeForm['Html']($.extend(values, {id: id}), (local.data || null)).render());
                            }
                            break;
                    }
                } catch (e) {
                    console.log('form error. not type of ' + type + ' \r\n because ' + e);
                }
            }
            local.work.template = $(Template.render('treeform', 'section', {
                id: local.config.id,
                title: local.config.title,
                expand: local.work.expand ? 'expanded' : 'unexpanded',
            }));
            let container = $('.tform-section-elements-container', local.work.template).eq(0);
            for (let i = 0; i < local.work.elements.length; i++) {
                container.append(local.work.elements[i]);
            }
            local.work.template.data({'container': container, 'object': this});
            $('.to-expand#expand_' + local.config.id, local.work.template).on('click', function () {
                if (local.work.template.hasClass('expanded')) {
                    local.work.template.addClass('unexpanded');
                    local.work.template.removeClass('expanded');
                } else {
                    local.work.template.removeClass('unexpanded');
                    local.work.template.addClass('expanded');
                }
            });
            return local.work.template;
        }
    };
    return fns;
};