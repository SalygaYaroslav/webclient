TreeForm.Html = function (config, data) {
    let local = {
        id: config.id,
        title: config.title,
        format: config.format,
        options: config.options,
        spit: config.split || ',',
        data: data || ''
    };
    let fns = {
        element: 'html',
        render: function () {
            let value = local.data[config.id];
            if (value == '') {
                return '';
            }
            local.element = $(Template.render('treeform', 'elements/html', {
                id: local.id,
                title: local.title,
                elements: function () {
                    let array = ((value) ? value.split(config.split) : []);
                    if (array.length == 0) {
                        array = [''];
                    }
                    let options_object = {};
                    if (typeof local.options != 'undefined') {
                        let options = TreeForm.Options[local.options]();
                        for (let i = 0; i < options.length; i++) {
                            options_object[options[i].value] = {
                                text: options[i].text,
                                dont_show: options[i].dont_show
                            };
                        }
                    }
                    for (let i = 0; i < array.length; i++) {
                        if (typeof local.format != 'undefined') {
                            array[i] = TreeForm.Format[local.format](local.data);
                        }
                        if (typeof local.options != 'undefined') {
                            if (options_object[array[i]].dont_show != true) {
                                array[i] = options_object[array[i]].text;
                            } else {
                                array[i] = '';
                            }
                        }
                        array[i] = TreeForm.Validate.text(array[i]);
                    }

                    return array;
                }()
            }));
            return local.element.data({'object': this});
        },
        title: function () {
            return '';
        }
    };
    return fns;
};