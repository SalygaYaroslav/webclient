TreeForm.String = function (config, data) {
    let local = {
        id: config.id,
        title: config.title,
        multi: config.multi,
        split: config.split || ',',
        data: data || '',
        placeholder: config.placeholder,
        visible: config.visible,
        element: null,
        input: null
    };
    let fns = {
        element: 'string',
        render: function () {
            local.element = $(Template.render('treeform', 'elements/string', {
                id: local.id,
                title: local.title,
                placeholder: local.placeholder,
                multi: local.multi.toString().toBoolean(),
                elements: function () {
                    let value = local.data[config.id];
                    let array = ((value) ? value.split(config.split) : []);
                    if (array.length == 0) {
                        array = [''];
                    }
                    for (let i = 0; i < array.length; i++) {
                        array[i] = TreeForm.Validate.text(array[i]);
                    }
                    return array;
                }()
            }));
            return local.element.data({'object': this});
        },
        title: function () {
            return '';
        }
    };
    return fns;
};