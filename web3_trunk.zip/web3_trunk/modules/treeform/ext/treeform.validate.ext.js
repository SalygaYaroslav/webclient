TreeForm.Validate = (function () {
    let local = {};
    let fns = {
        text: function (text) {
            if (text == 'null') {
                text = '';
            }
            text = text.replace('#empty#', '');
            return text;
        }
    };
    return fns;
})();